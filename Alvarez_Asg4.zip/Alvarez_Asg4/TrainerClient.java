package Alvarez_Asg4;

import Alvarez_Asg4.Pokemon;
import java.net.Socket;
import java.net.URL;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/** 
 * This class defines the client side of a socket connection for a pokemon care center
 * @author J. Alvarez
 * 2588
 * TrainerClient.java
 * 4/21/2025
 */
public class TrainerClient extends Application{
    private ComboBox<String> cbPokemonType = new ComboBox<String>();
    private TextField tfPokemonName = new TextField();
    private Button btSend = new Button("Send to Day Care");
    private Button btPickUp = new Button("Pick Up From Day Care");

    ObjectOutputStream osToServer;
    ObjectInputStream isFromServer;

    /**
     * Function starts the applications bootup sequence. Since it extends application, it must be overridden. 
     */
    @Override
    public void start (Stage primaryStage){
        GridPane gridpane = new GridPane();
        gridpane.add(new Label("Choose a Pokemon Type"), 0, 0);
        gridpane.add(new Label("Pokemon's Name"), 0, 1);
        gridpane.add(btSend, 0, 2);
        gridpane.add(cbPokemonType, 1, 0);
        gridpane.add(tfPokemonName, 1, 1);
        gridpane.add(btPickUp, 1, 2);
        
        BorderPane pane = new BorderPane();
        pane.setTop(gridpane);
        
        Scene scene = new Scene(pane, 300, 250);
        primaryStage.setTitle("Pokemon Trainer");
        primaryStage.setScene(scene);
        primaryStage.show();

        btPickUp.setDisable(true);

        String[] pokemonTypes = {"Charmander", "Squirtle", "Bulbasaur", "Pikachu"};
        cbPokemonType.getItems().addAll(pokemonTypes);

        new Thread(() -> {
            try {
                Socket connectToServer = new Socket("127.0.0.1", 8000);
                osToServer = new ObjectOutputStream(connectToServer.getOutputStream());
                osToServer.flush();
                isFromServer = new ObjectInputStream(connectToServer.getInputStream());

                // Once connected, enable buttons (on JavaFX thread)
                Platform.runLater(() -> {
                    btSend.setDisable(false);
                    btPickUp.setDisable(false);
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();

        btSend.setOnAction(e -> {
            String type = cbPokemonType.getValue();
            String name = tfPokemonName.getText();
            if (type != null && !name.isEmpty()) {
                Pokemon pokemon = new Pokemon(type, name);
                sendToDayCare(pokemon);
            }
        });

        btPickUp.setOnAction(e -> {
            String type = cbPokemonType.getValue();
            String name = tfPokemonName.getText();
            if (type != null && !name.isEmpty()) {
                Pokemon pokemon = new Pokemon(type, name);
                pickUpFromDayCare(pokemon);
            }
        });
    }

    /**
     * Function is the messanger that sends informatino from the client to the server that 
     * it is leaving a Pokemon in the server's center
     * @param pokemon -Pokemon object that is to be passed to the server
     */
    private void sendToDayCare(Pokemon pokemon){
        try{
            osToServer.writeObject(pokemon);
            osToServer.writeBoolean(true);
            osToServer.flush();
            btSend.setDisable(true);
            btPickUp.setDisable(false);
            tfPokemonName.setDisable(true);
            cbPokemonType.setDisable(true);
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    /**
     * Function is the messanger that sends informatino from the client to the server saying 
     * that it would like to take its pokemon back
     * @param pokemon -Pokemon object that is to be accepted from the server
     */
    private void pickUpFromDayCare(Pokemon pokemon){
        try{
            osToServer.writeObject(pokemon);
            osToServer.writeBoolean(false);
            osToServer.flush();
            btSend.setDisable(false);
            btPickUp.setDisable(true);
            tfPokemonName.setDisable(false);
            cbPokemonType.setDisable(false);
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args){
        launch(args);
    }
}
