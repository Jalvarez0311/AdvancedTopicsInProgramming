package Alvarez_Asg4;

import java.io.Serializable;
import java.util.UUID;

/** 
 * This class defines the client the Pokemon object to be used by both the client and server
 * @author J. Alvarez
 * 2588
 * Pokemon.java
 * 4/21/2025
 */
public class Pokemon implements Serializable{
    private UUID pokemonID;
    private String pokemonType;
    private String name;
    private boolean checkedIn;

    /**
     * Function is a Constructor for the Pokemon class
     * @param pokemonType -String value that identifies what type of pokemon the object is
     * @param name -String value that identifies the name of the pokemon
     */
    Pokemon(String pokemonType, String name){
        pokemonID = UUID.randomUUID();
        this.pokemonType = pokemonType;
        this.name = name;
        checkedIn = false;
    }

    /**
     * Function returns the number of the Pokemon's ID
     * @return -returns the number of the Pokemon's ID
     */
    public UUID getPokemonID(){
        return pokemonID;
    }

    /**
     * Function returns the Pokemon's type
     * @return -returns the Pokemon's type
     */
    public String getPokemonType() {
        return pokemonType;
    }

    /**
     * Function returns the Pokemon's name
     * @return -returns the Pokemon's name
     */
    public String getName() {
        return name;
    }

    /**
     * Function returns the boolean value of whether or not the pokemon is checked into the care center
     * @return -returns the boolean value of whether or not the pokemon is checked into the care center
     */
    public boolean isCheckedIn() {
        return checkedIn;
    }

    /**
     * Function changes the checkedIn value to true when the pokemon is checked in
     */
    public void checkIn(){
        checkedIn = true;
    }

    /**
     * Function changes the checkedIn value to false when the pokemon is checked out
     */
    public void checkOut(){
        checkedIn = false;
    }

}
