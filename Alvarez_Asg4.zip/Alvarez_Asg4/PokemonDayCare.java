package Alvarez_Asg4;

import Alvarez_Asg4.Pokemon;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Date;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

/** 
 * This class defines the server side of a socket connection for a pokemon care center
 * @author J. Alvarez
 * 2588
 * PokemonDayCare.java
 * 4/21/2025
 */

public class PokemonDayCare extends Application{
    
    private TextArea ta = new TextArea();
    static int connections = 0;
    @Override
    public void start (Stage primaryStage){
        Scene scene = new Scene(new ScrollPane(ta), 300, 250);
        primaryStage.setTitle("Pokemon Day Care");
        primaryStage.setScene(scene);
        primaryStage.show();

        new Thread(() -> connectToClient()).start();
    }

    /**
     * Function connects the server to a client
     */
    private void connectToClient(){
        try{
            ServerSocket serverSocket = new ServerSocket(8000);
            Platform.runLater(()-> ta.appendText("Server started at " + new Date() + "\n"));
            //listening to client
            Socket connectToClient = serverSocket.accept();
            connections++;
            Platform.runLater(()-> ta.appendText("New connection made with trainer. Total connections = " + connections + "\n"));
            Platform.runLater(()-> ta.appendText("Trainer's IP Address is " + connectToClient.getInetAddress().getHostAddress() + "\n"));
            ObjectInputStream isFromClient = new ObjectInputStream(connectToClient.getInputStream());

            while (true){
                Pokemon pokemon = (Pokemon) isFromClient.readObject();
                boolean isCheckedIn = isFromClient.readBoolean();

                if(isCheckedIn){
                    Platform.runLater(() -> ta.appendText("Pokemon " + pokemon.getName() + " has been checked in\n"));
                    pokemon.checkIn();
                }
                else{
                    Platform.runLater(() -> ta.appendText("Pokemon " + pokemon.getName() + " has been checked out\n"));
                    pokemon.checkOut();
                }
            }
        }
        catch(IOException | ClassNotFoundException e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args){
        launch(args);
    }
}
