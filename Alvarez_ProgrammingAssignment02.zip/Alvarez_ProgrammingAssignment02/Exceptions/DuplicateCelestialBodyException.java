package Alvarez_ProgrammingAssignment02.Exceptions;

public class DuplicateCelestialBodyException extends Exception{
    public DuplicateCelestialBodyException(String message){
        super(message);
    }
}