package Alvarez_ProgrammingAssignment02.Exceptions;

public class InvalidCelestialBodyException extends Exception{
    public InvalidCelestialBodyException (String message){
        super(message);
    }
}
