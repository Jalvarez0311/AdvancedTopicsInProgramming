package Alvarez_ProgrammingAssignment03.exceptions;

public class DuplicateCelestialBodyException extends Exception{
    public DuplicateCelestialBodyException(String message){
        super(message);
    }
}