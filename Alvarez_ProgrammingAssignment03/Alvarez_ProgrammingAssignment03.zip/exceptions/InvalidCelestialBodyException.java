package Alvarez_ProgrammingAssignment03.exceptions;

public class InvalidCelestialBodyException extends Exception{
    public InvalidCelestialBodyException(String message){
        super(message);
    }
}
